# Pokémon Text Reader

Android Studio project for an accessibility-based Pokémon game text reader.

## How it works
The app uses Android's AccessibilityService screenshot API and Google ML Kit on-device OCR to detect visible text, then Android Text-to-Speech reads new text aloud.

## Setup
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Build the APK with Build > Build APK(s).
4. Install it on an Android 11+ phone.
5. Open the app and enable **Pokémon Text Reader** under Android Accessibility settings.
6. Return to the app and press **Start Reader**.
7. Open a Pokémon game/emulator. When dialogue appears on screen, the reader will OCR it and speak it.

## Notes
- OCR accuracy depends on the game's font, scaling, contrast and emulator resolution.
- The first version reads the whole screen, so it may occasionally detect menus or unrelated text.
- A later version can add a crop box so only the Pokémon dialogue box is scanned.
