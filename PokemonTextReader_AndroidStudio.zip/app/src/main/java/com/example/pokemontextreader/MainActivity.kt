package com.example.pokemontextreader

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var lastText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggleButton)
        lastText = findViewById(R.id.lastText)

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        toggle.setOnClickListener {
            ReaderAccessibilityService.enabled = !ReaderAccessibilityService.enabled
            updateUi()
        }

        findViewById<SeekBar>(R.id.speedBar).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                    ReaderAccessibilityService.speechRate = 0.5f + (p / 100f)
                }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })

        updateUi()
    }

    override fun onResume() {
        super.onResume()
        updateUi()
        lastText.text = ReaderAccessibilityService.lastDetectedText
    }

    private fun updateUi() {
        val on = ReaderAccessibilityService.enabled
        status.text = if (on) "Reader is running" else "Reader is stopped"
        toggle.text = if (on) "Stop Reader" else "Start Reader"
    }
}
