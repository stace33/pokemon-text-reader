package com.example.pokemontextreader

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class ReaderAccessibilityService : AccessibilityService(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var lastSpoken = ""
    private var busy = false

    companion object {
        @Volatile var enabled = false
        @Volatile var speechRate = 1.0f
        @Volatile var lastDetectedText = "Detected text will appear here."
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        tts = TextToSpeech(this, this)
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!enabled || busy) return
        scheduleCapture()
    }

    override fun onInterrupt() {}

    private fun scheduleCapture() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ captureScreen() }, 350)
    }

    private fun captureScreen() {
        if (!enabled || busy) return
        busy = true
        takeScreenshot(0, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = result.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                hw.close()
                if (bitmap != null) recognize(bitmap.copy(Bitmap.Config.ARGB_8888, false))
                else busy = false
            }
            override fun onFailure(errorCode: Int) { busy = false }
        })
    }

    private fun recognize(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val cleaned = result.text.lines()
                    .map { it.trim() }
                    .filter { it.length >= 2 }
                    .joinToString(" ")
                    .replace(Regex("\\s+"), " ")
                if (cleaned.isNotBlank()) {
                    lastDetectedText = cleaned
                    if (cleaned != lastSpoken) {
                        lastSpoken = cleaned
                        tts.setSpeechRate(speechRate)
                        tts.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, "pokemon_text")
                    }
                }
            }
            .addOnCompleteListener { busy = false }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::tts.isInitialized) tts.shutdown()
        recognizer.close()
        super.onDestroy()
    }
}
